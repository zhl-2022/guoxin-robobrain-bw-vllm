# Archived SGLang native result reanalysis

Native output_lens can come from stream usage or requested-length fallback; raw SSE usage, terminal framing, and exact 1024 generated tokens are not independently certified by this JSONL. Upstream combines reasoning_content/content.

Only request_rate Infinity is normalized. Original producer statuses and every native file SHA remain in analysis.json.

| Load | Producer status | Exit/process | Reanalysis | Completed | Output token/s | Wall seconds |
|---|---|---|---|---:|---:|---:|
| round1_4096_1024_c64 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 128 | 79.509666871754 | 1825.512776 |
| round2_4096_1024_c64 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 128 | 79.55036947533729 | 1801.949408 |
| round1_16384_1024_c1 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 8 | 19.23721935214311 | 484.194203 |
| round2_16384_1024_c1 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 8 | 19.314621503747258 | 478.787526 |
| round1_16384_1024_c8 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 16 | 53.05562671710333 | 369.159419 |
| round2_16384_1024_c8 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 16 | 53.34195286695541 | 375.575493 |
| round1_16384_1024_c64 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 128 | 51.094184528086146 | 2796.24543 |
| round2_16384_1024_c64 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 128 | 50.70737850703187 | 2794.947752 |

Eligible native client reports: 8/8. Official acceptance: false. Exact output token proof: false.
