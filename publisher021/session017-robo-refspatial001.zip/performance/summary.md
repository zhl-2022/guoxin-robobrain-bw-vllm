# SGLang client performance record

Official acceptance: false. upstream output_lens may use stream usage or requested-length fallback; exact 1024-token output is not independently certified
Configured server framework: vllm. Upstream client sender alias: sglang-oai-chat; OpenAI /v1/chat/completions. SGLang0.5.12 image dataset permits sglang-oai-chat, not vllm-chat; both aliases map to the same upstream OpenAI chat sender. The sender alias does not identify the server framework or create a SGLang-serving contest piece.

| Round | Text target | Concurrency | Completed | Output token/s | Mean TTFT ms | Client wall s | Status |
|---|---|---|---|---|---|---|---|
| 1 | 4096 | 1 |  |  |  | 423.769164 | invalid_native_result |
| 2 | 4096 | 1 |  |  |  | 413.199332 | invalid_native_result |
| 1 | 4096 | 8 |  |  |  | 249.717607 | invalid_native_result |
| 2 | 4096 | 8 |  |  |  | 239.141604 | invalid_native_result |
| 1 | 4096 | 64 |  |  |  | 2359.608905 | interrupted |
| 2 | 4096 | 64 |  |  |  |  | not_attempted_interrupted |
| 1 | 16384 | 1 |  |  |  |  | not_attempted_interrupted |
| 2 | 16384 | 1 |  |  |  |  | not_attempted_interrupted |
| 1 | 16384 | 8 |  |  |  |  | not_attempted_interrupted |
| 2 | 16384 | 8 |  |  |  |  | not_attempted_interrupted |
| 1 | 16384 | 64 |  |  |  |  | not_attempted_interrupted |
| 2 | 16384 | 64 |  |  |  |  | not_attempted_interrupted |
