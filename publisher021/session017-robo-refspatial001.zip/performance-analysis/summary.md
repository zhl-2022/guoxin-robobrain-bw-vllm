# Archived SGLang native result reanalysis

Native output_lens can come from stream usage or requested-length fallback; raw SSE usage, terminal framing, and exact 1024 generated tokens are not independently certified by this JSONL. Upstream combines reasoning_content/content.

Only request_rate Infinity is normalized. Original producer statuses and every native file SHA remain in analysis.json.

| Load | Producer status | Exit/process | Reanalysis | Completed | Output token/s | Wall seconds |
|---|---|---|---|---:|---:|---:|
| round1_4096_1024_c1 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 8 | 21.77702301979872 | 423.769164 |
| round2_4096_1024_c1 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 8 | 22.18683497733651 | 413.199332 |
| round1_4096_1024_c8 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 16 | 81.42582984321376 | 249.717607 |
| round2_4096_1024_c8 | invalid_native_result | 0/exited | complete_native_client_report_reanalyzed | 16 | 83.97684585471296 | 239.141604 |
| round1_4096_1024_c64 | interrupted | 130/interrupted | not_eligible |  |  | 2359.608905 |
| round2_4096_1024_c64 | not_attempted_interrupted | None/None | not_eligible |  |  | None |
| round1_16384_1024_c1 | not_attempted_interrupted | None/None | not_eligible |  |  | None |
| round2_16384_1024_c1 | not_attempted_interrupted | None/None | not_eligible |  |  | None |
| round1_16384_1024_c8 | not_attempted_interrupted | None/None | not_eligible |  |  | None |
| round2_16384_1024_c8 | not_attempted_interrupted | None/None | not_eligible |  |  | None |
| round1_16384_1024_c64 | not_attempted_interrupted | None/None | not_eligible |  |  | None |
| round2_16384_1024_c64 | not_attempted_interrupted | None/None | not_eligible |  |  | None |

Eligible native client reports: 4/12. Official acceptance: false. Exact output token proof: false.
